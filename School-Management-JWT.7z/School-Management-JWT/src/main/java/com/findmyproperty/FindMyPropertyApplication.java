package com.findmyproperty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FindMyPropertyApplication {

	public static void main(String[] args) {
		SpringApplication.run(FindMyPropertyApplication.class, args);
	}
}
