package com.findmyproperty.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PropertiesController {

	@GetMapping(value = "/admin/getpropertyList")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ResponseEntity<?> getPropertiesList() {

		List<String> list = new ArrayList<>();
		list.add("Noida");
		list.add("Delhi");
		list.add("Mumbai");

		return ResponseEntity.ok().body(list);
	}

	@GetMapping(value = "/app/users")
	@PreAuthorize("hasRole('ROLE_USER')")
	public ResponseEntity<?> getUsers() {

		List<String> list = new ArrayList<>();
		list.add("SUD");
		list.add("JOHN");
		list.add("KATY");

		return ResponseEntity.ok().body(list);
	}

}
