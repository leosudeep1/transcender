package com.findmyproperty.oauth.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.findmyproperty.entity.AppUser;
import com.findmyproperty.repository.IUserRepository;

@Service
public class AppUserDetailsService implements UserDetailsService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AppUserDetailsService.class);

	@Autowired
	private IUserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		AppUser user = null;
		try {
			user = userRepository.findByEmail(email);
			if (null == user) {
				LOGGER.error("Email not found");
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		LOGGER.info(user.getRoles().toString());
		return new User(user.getEmail(), user.getPassword(), user.getRoles());
	}

}
