package com.findmyproperty.repository;

import org.springframework.data.repository.CrudRepository;

import com.findmyproperty.entity.AppUser;
import java.lang.String;
import java.util.List;

public interface IUserRepository extends CrudRepository<AppUser, Long>{

	public AppUser findByEmail(String email) throws Exception;
}
