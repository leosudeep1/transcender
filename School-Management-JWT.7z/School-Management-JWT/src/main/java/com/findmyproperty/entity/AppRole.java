package com.findmyproperty.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.springframework.security.core.GrantedAuthority;

@Entity
@Table(name = "TAB_ROLE")
public class AppRole implements GrantedAuthority {

	private static final long serialVersionUID = 4803385547980783211L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	@Column(name = "ROLE", unique = true, nullable = false)
	private String role;

	@ManyToMany(mappedBy = "roles")
	private Set<AppUser> users;

	@Override
	public String getAuthority() {
		// TODO Auto-generated method stub
		return this.role;
	}

	@Override
	public String toString() {
		return "AppRole [role=" + role + "]";
	}

}
