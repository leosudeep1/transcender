package com.findmyproperty.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BasicDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "GENDER", nullable = false)
	private String gender;

	@Column(name = "PROFILE_PIC", nullable = true)
	private String profilePic;

	@Column(name = "DOB", nullable = false)
	private Date dob;

	@Column(name = "CREATION_DATE", nullable = false)
	private Date profileCreationDate;

	@Column(name = "IP", nullable = false)
	private String ip;

	@Column(name = "CITY", nullable = false)
	private String city;

	@Column(name = "STATE", nullable = false)
	private String state;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getProfilePic() {
		return profilePic;
	}

	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Date getProfileCreationDate() {
		return profileCreationDate;
	}

	public void setProfileCreationDate(Date profileCreationDate) {
		this.profileCreationDate = new Date();
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "BasicDetails [id=" + id + ", gender=" + gender + ", profilePic=" + profilePic + ", dob=" + dob
				+ ", profileCreationDate=" + profileCreationDate + ", ip=" + ip + ", city=" + city + ", state=" + state
				+ "]";
	}

}
